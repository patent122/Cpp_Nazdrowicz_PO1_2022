#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

/*
Zadanie 2: Napisz klasę macierz, która służy do przechowywania macierzy liczb wymiernych. Klasa 
macierz powinna udostępniać następujące publiczne metody: — konstruktor, który otrzymuje dwie liczby 
całkowite i inicjuje macierz o wymiarach podanych w argumentach, — przeciążony operator (), który dla 
liczb całkowitych i, j podanych jako argumenty zwraca referencję do elementu macierzy znajdującego się 
i-tej kolumnie i j-wierszu. Do implementacji klasy macierz wykorzystaj typ vector.
*/

class Macierz
{
public:
	Macierz(int kolumny, int wiersze)
	{
		komorki.resize(wiersze);
		for (auto& wiersz : komorki)
		{
			wiersz.resize(kolumny);
		}
	}

	double& operator()(int kolumna, int wiersz)
	{
		return komorki[wiersz][kolumna];
	}
private:
	vector<vector<double>> komorki;
};

int main(int argc, char** argv)
{
	Macierz macierz(5, 3);

	srand(time(nullptr));

	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			macierz(i, j) = rand() / (double)RAND_MAX;
			cout << right << setw(15) << macierz(i, j);
		}
		cout << endl;
	}

	return 0;
}
