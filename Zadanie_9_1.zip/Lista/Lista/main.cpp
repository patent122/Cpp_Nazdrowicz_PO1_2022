#include <iostream>
#include <iterator>
#include <list>

using namespace std;

bool compare(const int& a, const int& b)
{
	return a > b;
}

int main(int argc, char** argv)
{
	list<int> lista;
	int n;

	cout << "Podaj n: ";
	cin >> n;

	if (n <= 0)
	{
		return -1;
	}

	for (int i = 0; i < n; i++)
	{
		int liczba;

		cout << "Podaj liczbe: ";
		cin >> liczba;

		if (liczba >= 0)
		{
			lista.push_back(liczba);
		}
		else
		{
			lista.push_front(liczba);
		}
	}

	lista.sort(compare);

	list<int>::iterator it = lista.begin();

	for (int i = 0; i < n; i++)
	{
		cout << "lista[" << i << "] = " << *it << endl;
		it++;
	}

	return 0;
}
