#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

/*
Zadanie Extra 1: Napisz funkcję, która otrzymuje jako argument referencję do obiektu klasy 
vector<int> i: 
a) odwraca kolejność elementów w otrzymanym w argumencie kontenerze, 
b) sortuje rosnąco elementy otrzymanego w argumencie kontenera, 
c) sortuje malejąco elementy otrzymanego w argumencie kontenera, 
d) sortuje rosnąco elementy otrzymanego w argumencie kontenera względem ich wartości bezwzględnych, 
e) sortuje rosnąco elementy otrzymanego w argumencie kontenera względem ich reszty z dzielenia przez 1000.
*/

void print(vector<int>& v)
{
	for (int item : v)
	{
		cout << item << " ";
	}
	cout << endl;
}

void extra(vector<int>& v)
{
	print(v);
	reverse(v.begin(), v.end());
	print(v);
	sort(v.begin(), v.end());
	print(v);
	sort(v.begin(), v.end(), [](auto& a, auto& b) { return b < a; });
	print(v);
	sort(v.begin(), v.end(), [](auto& a, auto& b) { return abs(a) < abs(b); });
	print(v);
	sort(v.begin(), v.end(), [](auto& a, auto& b) { return a % 1000 < b % 1000; });
	print(v);
}

int main(int argc, char** argv)
{
	vector<int> v = { 1, -2, 3, 4, -5, 6, -7, 8000, 9000 };

	extra(v);

	return 0;
}
